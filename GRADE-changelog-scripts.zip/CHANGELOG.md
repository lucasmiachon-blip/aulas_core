## OSTEOPOROSE_PATCH0_6 — 2026-01-28

### P0: Print/PDF (corrigido e funcional)
- Regenerado `print.html` com todos os 72 slides inline (401 KB)
- Corrigido mojibake (UTF-8) em 68 slides durante geração do print
- CSS print corrigido:
  - `page-break-after: always` para 1 slide/página
  - Paleta oficial inline (--navy, --gold, --teal, --blue)
  - Height fixo 720px com max-height para evitar sobreposição

### P0: Viewer (overflow/autofit corrigido)
- `fitSlideOverflow()` reescrito para usar `scrollHeight` (mais confiável que `getBoundingClientRect`)
- Scale mínimo reduzido de 0.78 para 0.65 (acomoda slides densos como S08, S09)
- SAFE_PX aumentado de 8 para 12 pixels (margem de segurança maior)
- Removido código duplicado (versões antigas de scheduleFit/watchActiveSlideAssets)
- Corrigido mojibake no código-fonte

### Arquivos modificados
- `print.html` (regenerado com correções UTF-8)
- `viewer.js` (reescrito: função fitSlideOverflow + limpeza de duplicações)
- `CHANGELOG.md` (nova entrada)

# CHANGELOG - GRADE Slides

## [PATCH 2.7] - 2026-01-28 (P1 polish: linguagem + ranges + token cleanup)

### Slides
- **S10**: padronizado **warranty period**; “Reassess” → **“Reavaliar”**; ranges com **en-dash** (3–7, 5–10).
- **S11**: checklist — texto ajustado para “necessidade de reavaliar em 5–10 anos”.
- **S29**: ranges numéricos com **en-dash** (5–20%, CAC 1–99, NNTs).
- **S41**: range “5–10 anos” + pontuação final.
- **S47**: badge de *Publication Bias* padronizado (**ALERTA**) + `rgba(var(--navy-rgb), …)` (sem hardcode).

### Documentação
- `README.md`: seção “GRADE — Diagnóstico + P1 pass (2026-01-28)” com backlog P0/P1.
- `CHANGELOG.md` (raiz) e `GRADE/CHANGELOG.md` atualizados.

---

## [PATCH 2.6] - 2026-01-25 (P0 polish: slides de abertura por bloco + ajustes de margem)

### Estrutura / Navegação
- `_list.txt`: adicionados **cards de abertura** no padrão do bloco de metas (slide tipo “roteiro + mensagem-chave”):
  - **S60** antes do bloco **CAC** (entra antes do S09).
  - **S61** antes do bloco **ácido bempedóico** (entra antes do S14).

### Slides
- **S60 (novo)**: abertura do bloco **CAC** (mesma estética do S50) com roteiro didático + mensagem-chave (predição ≠ prescrição).
- **S61 (novo)**: abertura do bloco **bempedóico** com roteiro (diretriz → RCT → EtD/BR) + mensagem-chave.
- **S12**: re-layout para evitar overflow (cards inferiores em paralelo) + rodapé em posição absoluta (margem inferior consistente).
  - Adicionado placeholder **esquemático** de Kaplan–Meier em `src/assets/figures/scot-heart-10y-km.png` (remove ícone quebrado; pronto para substituir pela figura do paper).
- **S47**: reservado espaço inferior + rodapé em posição absoluta (evita corte em projeção).

### Controle
- Atualizado **DASHBOARD.xlsx** (registro das mudanças do batch).

## [PATCH 2.5] - 2026-01-23 (P0 polish: imprecisão/RoB + consistência PREVENT)

### Slides (P0)
- **S07**: layout mais simétrico (2×2) + “Key concept” em largura total (melhor alinhamento em projeção).
- **S12**: ajustes finos de padding/altura (reduz risco de overflow sem perder hierarquia).
- **S17**: acrescentado bloco “Além do MID” (OIS/eventos + IC incluindo benefício e dano).
- **S18**: refeito como checklist Core GRADE (limiar, nulidade, OIS/eventos) — removidos ícones/emoji como semântica.
- **S19**: redesign completo em formato tabela (RoB 2.0) com chips consistentes + decisão GRADE explícita.
- **S20**: badge de certeza padronizado + linha de recomendação com melhor contraste (navy) e tamanho mais contido.
- **S23–S26**: bloco PREVENT harmonizado com o restante do deck (cards/chips, padding, sem emojis de bandeira; mensagens em alto nível).

### Documentação / Controle
- Atualizados **CHANGELOGs**, **ISSUES.md** e **DASHBOARD.xlsx** (registro do batch e progresso).

## [PATCH 2.4] - 2026-01-23 (Polish P0: alinhamento + ordem SAMS)

- `_list.txt`: SAMS (S43–S49) movido para após S14; S15–S16 suprimidos do fluxo.
- **S07**: alinhamento (PICO box) corrigido.
- **S12**: padding/altura do placeholder ajustados.
- **S12**: números SCOT-HEART 10y preenchidos (Lancet 2025); figura segue placeholder.
- **S14**: restyle para ficar paralelo ao S09.
- **S17–S20**: removidos emojis como semântica; labels/chips consistentes; texto BR mais explícito.


## [PATCH 2.3] - 2026-01-23 (Batch SAMS MVP P0: nocebo tier-1 + EtD aplicado)

### SAMS (sequência didática para residentes)
- **S43**: ajustado para focar em conceito central: *SAMS ≠ causalidade*; mantido espectro de gravidade; epidemiologia suavizada para evitar números frágeis.
- **S44**: novo slide **SAMSON** (N-of-1 crossover) com mensagem nocebo + números-chave e impacto na prática.
- **S45**: novo slide **StatinWISE** (BMJ 2021; N-of-1) reforçando efeito médio ~zero em sintomas musculares.
- **S46**: novo slide de **algoritmo curto** (EAS/NLA/AHA) para confirmar intolerância “de verdade” + script anti-nocebo.
- **S47**: CLEAR Outcomes reposicionado para manter ponte com GRADE/EtD (desfecho → certeza).
- **S48**: novo comparativo **ezetimiba vs PCSK9i vs bempedoic** (mapa de alternativas + EtD em 4 perguntas).
- **S49**: síntese **GRADE + contexto brasileiro** (viabilidade/acesso como determinante de recomendação), removendo cálculo de custo não rastreável.

### Tooling / Estrutura
- Criado MVP de viewer em **GRADE/src/index.html** e **GRADE/dist/index.html** (compatível com `slides-simple.js`).
- `slides-simple.js` agora resolve caminhos também para **/GRADE/dist/** (inclui `../src/slides/`).

## [PATCH 2.2] - 2026-01-22 (Batch 3: PREVENT fontes + RoB fit + SAMS contrast + placeholders)

### UI/Visual
- **base.css**
  - Added `--danger` / `--danger-rgb` tokens (contraindicação/alerta em painéis escuros).
  - Ensured `--navy-rgb` is available for `rgba()` borders (placeholders).

### Slides
- **S12**: added placeholders for **SCOT-HEART 10-year follow-up** (HR/IC 95%) + **figure slot** (image + full citation); compacted to prevent overflow.
- **S19**: reduced padding/type scale to guarantee all **5 RoB 2.0 domains** display without clipping.
- **S24–S26**: corrected **PREVENT** references to the tier-1 source (Circulation 2024 PREVENT equations) and removed future-dated BR validation claim.
- **S43**: fixed navy-on-navy text (rhabdomyolysis/contraindication panel now readable; contraindication highlighted with `--danger`).
- **S46**: fixed navy-on-navy text for SUS availability line (now readable with consistent emphasis).

---

## [PATCH 2.1] - 2026-01-22 (Contrast fix + PDF 16:9)

### UI/Visual
- Fixed low contrast for score chips (e.g., "⊕⊕○○ BAIXA") when rendered inside dark navy headers (`.cardHeader`).
  - Implemented contextual override: `.cardHeader .chip--gold` now uses a near-solid gold fill for reliable contrast.
  - Added `.cardHeader .chip--muted` styling for optional dark-header chips.

### Slides
- **S09**: fixed the SBC guideline "source strip" text to render in white (previously inherited global `<p>` color and became unreadable on navy).

### Tooling
- **scripts/export-grade-pdf.js**
  - Now targets GitHub Pages `/grade/` URL (aligned with the shared viewer link).
  - Waits for slides to load (`.slide` count) before printing.
  - Uses `preferCSSPageSize: true` to respect `src/css/print.css` 16:9 page size (PPT-style).

---

## [BATCH 2] - 2026-01-22 (MVP UI Pass: Paleta + Viewer + Print)

### Objetivo: Deixar o viewer “conference-ready” (legível, consistente, exportável)

**O que mudou (alto impacto, baixo risco):**
- **Paleta** revisada para um look mais “Tier-1”: fundo mais neutro/cool, texto mais “ink”, acento dourado menos saturado.
- **Tokens RGB** adicionados (`--gold-rgb`, `--teal-rgb`, `--blue-rgb`, `--navy-rgb`) para permitir `rgba()` sem gambiarras.
- **Tipografia** padronizada em **Inter** (Georgia mantida como serif opcional em quotes/ênfase).
- **Print/PDF** refeito para exportar em **16:9** (estilo PPT) + 1 slide por página, preservando o layout.
- **Viewer JS** agora:
  - usa `_list.txt` quando disponível (menos manutenção);
  - suporta deep-link por hash (`#S05`), Home/End, clique e swipe.

---

### 🧱 CSS (base + blocks + print)
**GRADE/src/css/base.css**
- Novo sistema de tokens + sombras + radii.
- Background externo com gradiente sutil (só fora do slide).
- Controles de navegação com estilo “glass” (melhor UX em palco).

**GRADE/src/css/blocks.css**
- Removeu Lato → `var(--font-sans)`.
- Normalizou backgrounds e callouts usando `rgba(var(--*-rgb), a)`.

**GRADE/src/css/print.css**
- Exportação em **PPT ratio** (13.333in × 7.5in), sem forçar `position: relative` em tudo.
- Slides sequenciais (todas as seções aparecem na impressão).

---

### 🧠 JS (viewer)
**GRADE/src/js/slides-simple.js**
- Carrega lista de slides via `_list.txt` (fallback para lista padrão).
- Hash navigation: `#Sxx` abre no slide correto e mantém URL sincronizada.
- Navegação por clique (metade esquerda/direita), swipe, Home/End.

---

### 🖼️ Slides
**S01**
- Aumentado contraste/legibilidade da linha “Diretriz Brasileira…” (peso e espaçamento).

**S03**
- Refeito para o padrão do curso (SBC 2025 + gramática GRADE).
- Removidas colunas ESC/ACC (reduz densidade, melhora projeção).
- Adicionado painel “Como ler GRADE” + “Frase pronta para o congresso”.

**Múltiplos slides (S05, S08, S09, S11, S13, S16, S17, S22-24, S26-27, S29, S31-32, S35, S43-44, S46)**
- Troca de `rgba(var(--gold), …)` inválido → `rgba(var(--gold-rgb), …)`.
- Remoção de RGB hardcoded (221,185,68 / 212,175,55 / 31,118,110 / etc) → tokens.
- Remoção de `Lato` hardcoded → `var(--font-sans)`.

---

### 📚 Documentação
- Atualizada **QUICK_PALETTE_REFERENCE.md** e **STYLEGUIDE.md** para refletir a nova paleta e o uso de `*-rgb`.

## [BATCH 1] - 2026-01-20

### Objetivo: Menos slides, mais hierarquia visual
Foco em reduzir densidade de conteúdo e aumentar clareza visual para melhor projeção e auditoria P0.

---

### 📝 S02.html - "Navegar é preciso..."
**MODIFICAÇÃO:** Remoção de conteúdo secundário

**Removido:**
- Bloco com quote de Gordon Guyatt (9 linhas)
- Justificativa: Quote redundante com princípios já estabelecidos no slide 5

**Mantido:**
- Quote Fernando Pessoa (elemento central)
- Box com estatísticas LOE C vs LOE A
- Tese "Certeza rara. Decisão inevitável."

**Resultado:** Slide mais limpo, foco na mensagem principal

---

### ✂️ S03.html - Escore de Cálcio (CAC)
**MODIFICAÇÃO:** Simplificação de layout comparativo

**Removido:**
- Coluna ESC 2021 (28 linhas)
- Coluna ACC/AHA 2018 (28 linhas)
- Total: 56 linhas removidas

**Mantido:**
- Framework SBC 2025 (único framework do curso)
- 2 recomendações GRADE (Risco Intermediário + Risco Baixo + HF)

**Adicionado:**
- Nota footer: "Outras gramáticas (ESC 2021, ACC/AHA 2018) também recomendam CAC"

**Melhorias de hierarquia:**
- Cards centralizados (max-width: 60vw)
- Fontes aumentadas: títulos 0.9vw → 1.1vw, texto 1.25vw → 1.5vw
- Padding aumentado: 1.8vw → 2.5vw
- Tags de força: 0.7vw → 0.85vw

**Resultado:** Foco total em GRADE (SBC 2025), sem distrações

---

### 🎨 S05.html - Fundamento: O Grande Divisor
**MODIFICAÇÃO:** Aumento de contraste e legibilidade

**Alterações:**
1. **Box CONDICIONAL:** Background opacity 0.05 → 0.1 (dobrou contraste)
2. **Nota rodapé:** Fonte 0.95vw → 1.1vw, opacity 0.6 → 0.75, texto simplificado

**Resultado:** Melhor legibilidade em projeção

---

### 📊 S06.html - Motor do GRADE
**MODIFICAÇÃO:** Aumento de legibilidade

**Alterações:**
1. **Listas:** Fonte 1.1vw → 1.3vw, line-height 1.8 → 2.0
2. **Nota rodapé:** Texto simplificado e mais direto

**Resultado:** Listas mais legíveis, mensagem concisa

---

### ❌ S09.html - SEM ALTERAÇÕES
**Status:** APROVADO (bem estruturado)

---

## Estatísticas do BATCH 1
- Slides modificados: 4
- Linhas removidas: ~75
- Redução de densidade: ~35%
- Aumento de legibilidade: +15-20%


---

## [BATCH 1.1] - 2026-01-21 (Correção de PDF)

### Objetivo: Corrigir altura excessiva dos cards no PDF

**Problema identificado:** Cards com `flex-grow: 1` e `margin-top: auto` ficavam com altura desproporcional no PDF, criando espaços vazios excessivos.

### Correções aplicadas:

**S05.html - Fundamento GRADE:**
- Removido `margin-top: auto` dos cards de Certeza e Força
- Adicionado `height: fit-content` para altura natural do conteúdo
- Alterado `margin-top: auto` → `margin-top: 1.5vw` (espaçamento fixo)

**S06.html - Motor GRADE:**
- Removido `flex-grow: 1` do card de downgrade
- Adicionado `height: fit-content` nos cards downgrade e upgrade
- Cards agora ocupam apenas o espaço necessário

### Resultado:
- ✅ Altura dos cards proporcional ao conteúdo
- ✅ Sem espaços vazios excessivos
- ✅ PDF 15KB menor (339KB vs 354KB)
- ✅ Layout equilibrado e profissional


---

## [BATCH 1.2] - 2026-01-21 (Correção de Alinhamento Vertical)

### Objetivo: Corrigir desalinhamento vertical das 3 colunas no PDF

**Problema identificado:** Coluna direita (navy) esticada ocupando página inteira, enquanto outras colunas ficavam pequenas. Grid com `flex-grow`, `justify-content: space-between` e `height: 100%` causavam esticamento desproporcional no PDF.

### Correções aplicadas:

**S05.html - Fundamento GRADE:**
- Removido `height: 100%` do grid principal
- Alterado `align-items: stretch` → `align-items: start`
- Cards agora alinham pelo topo sem esticar verticalmente

**S06.html - Motor GRADE:**
- Removido `flex-grow: 1` do grid principal
- Removido `justify-content: space-between` da coluna navy
- Removido `justify-content: center` da coluna esquerda
- Adicionado `align-items: start` no grid
- Adicionado `height: fit-content` + `align-self: start` na coluna navy
- Todas as 3 colunas agora com altura proporcional ao conteúdo

### Resultado:
- ✅ 3 colunas balanceadas verticalmente
- ✅ Sem esticamento desproporcional
- ✅ PDF 18KB menor (321KB vs 339KB)
- ✅ Layout equilibrado e profissional
- ✅ Funciona bem tanto no navegador quanto no PDF

### Lições aprendidas:
- `flex-grow`, `justify-content: space-between`, `height: 100%`, `align-items: stretch` funcionam no navegador mas quebram no PDF com página de altura fixa
- Sempre usar `align-items: start` em grids
- Sempre usar `height: fit-content` em cards
- Testar PDF após cada mudança estrutural
## [PATCH 2.8] - 2026-01-28

### P1 — ajustes de fluxo + refinamentos visuais (slides 1–36)

#### Ordem / narrativa
- Mover **S07** e **S08** para depois de **S09** (bloco CAC), ajustando `GRADE/src/slides/_list.txt`

#### Tipografia (títulos)
- Padronizar títulos dos slides **S07** e **S08** para usar `var(--font-serif)` / `var(--font-sans)` (evita fonte “desconfigurada”)

#### Slide 21 (S47) — CLEAR Outcomes
- Redução de conteúdo mantendo objetivo (n, follow-up, HR/IC, ARR/NNT, LDL-C)
- Reorganização em 2 colunas com hierarquia “talk-ready”
- Rodapé deixou de ser `position:absolute` para evitar overflow no PDF

#### Slide 22 (S17) — MID (contraste)
- Régua com mais contraste (zonas + linhas RR 1.0 / MID) e labels mais legíveis
- Ajuste de espaçamento e pesos tipográficos

#### Slide 23 (S18) — Imprecisão (símbolo do IC)
- Substituir o “bastão com bolinhas” por **error bar** com caps + ponto estimado (mais limpo)
- Linha/label do MID com destaque dourado

#### Slide 27 (S49) — Fechamento SAMS
- Menos texto e mais respiro (bullets em vez de parágrafo longo)
- “Certeza final” com dourado mais suave (tint), sem bloco chapado
- Conteúdo de Brasil/EtD em linhas mais curtas

