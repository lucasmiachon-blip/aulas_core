# Sources (GRADE)

- [TBD] Registrar aqui todas as fontes (PDFs, figuras, tabelas, sites, artigos).
- Para cada item, incluir: título, autoria, ano, link/arquivo em `assets/`.
