# Decisions (GRADE)

- [TBD] Decisões de design, recortes de conteúdo, trade-offs e justificativas.
