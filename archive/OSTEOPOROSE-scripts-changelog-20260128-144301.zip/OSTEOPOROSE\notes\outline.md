# Outline (OSTEOPOROSE)

[TBD]
